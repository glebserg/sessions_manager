
from shemes import DBItemReader


class ActiveSession(DBItemReader):
    name: str
