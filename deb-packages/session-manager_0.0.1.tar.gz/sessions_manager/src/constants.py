
NAME_APP_SYSTEM="global_system"  # "системное" приложение
UPDATE_COUNTER_RATE=60  # секунды
USER_INSPECT_RATE=5  # секунды